from flask import Flask, request, render_template, send_from_directory, jsonify
import os
import cv2
import qrcode
import numpy as np

app = Flask(__name__)
UPLOAD_FOLDER = "static/uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route("/")
def home():
    return render_template("generate.html")

@app.route("/scan")
def scan_page():
    return render_template("scan.html")

@app.route("/generate_qr", methods=["POST"])
def generate_qr():
    data = request.form.get("data")
    if not data:
        return jsonify({"error": "No data provided"}), 400

    qr_filename = f"qr_{hash(data)}.png"
    qr_path = os.path.join(UPLOAD_FOLDER, qr_filename)

    # Generate QR Code
    qr = qrcode.make(data)
    qr.save(qr_path)

    return jsonify({
        "image_url": f"/static/uploads/{qr_filename}",
        "text": data
    })

@app.route("/scan_qr", methods=["POST"])
def scan_qr():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No selected file"}), 400

    filepath = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(filepath)


    img = cv2.imread(filepath)
    detector = cv2.QRCodeDetector()
    data, bbox, _ = detector.detectAndDecode(img)

    if data:
        return jsonify({"decoded_text": data})  # Return decoded text
    else:
        return jsonify({"error": "No QR code detected"}), 400

@app.route("/static/uploads/<filename>")
def uploaded_file(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

if __name__ == "__main__":
    app.run(debug=True)